
import React, { useState, useEffect } from 'react';
import { AppView, Photo, Person } from './types';
import Sidebar from './components/Sidebar';
import Dashboard from './components/Dashboard';
import Gallery from './components/Gallery';
import PeopleView from './components/PeopleView';
import MailCenter from './components/MailCenter';
import ShareModal from './components/ShareModal';
import { analyzePhotoWithGemini } from './services/geminiService';

const App: React.FC = () => {
  const [currentView, setCurrentView] = useState<AppView>(AppView.DASHBOARD);
  const [photos, setPhotos] = useState<Photo[]>([]);
  const [people, setPeople] = useState<Person[]>([]);
  const [isUploading, setIsUploading] = useState(false);
  const [uploadProgress, setUploadProgress] = useState(0);
  const [sortingStatus, setSortingStatus] = useState("");
  
  // UI State for Creating Folders
  const [isCreatingFolder, setIsCreatingFolder] = useState(false);
  const [newFolderName, setNewFolderName] = useState("");
  const [sharingTarget, setSharingTarget] = useState<Person | null>(null);

  const [sharingPhoto, setSharingPhoto] = useState<Photo | null>(null);
  const [previewPhoto, setPreviewPhoto] = useState<Photo | null>(null);

  useEffect(() => {
    setPhotos([]);
    setPeople([]);
  }, []);

  const handleCreateFolder = async (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (!file || !newFolderName.trim()) return;

    const photoUrl = URL.createObjectURL(file);
    const newPerson: Person = {
      id: `folder_${Math.random().toString(36).substr(2, 5)}`,
      name: newFolderName,
      thumbnailUrl: photoUrl,
      photoCount: 0,
      email: ''
    };

    setPeople(prev => [...prev, newPerson]);
    setNewFolderName("");
    setIsCreatingFolder(false);
    setCurrentView(AppView.PEOPLE);
  };

  const handleBulkUpload = async (event: React.ChangeEvent<HTMLInputElement>) => {
    const files = event.target.files;
    if (!files || files.length === 0) return;

    setIsUploading(true);
    setUploadProgress(0);
    const totalFiles = files.length;
    const existingFolderNames = people.map(p => p.name);

    for (let i = 0; i < totalFiles; i++) {
      const file = files[i];
      setSortingStatus(`Sorting ${file.name}...`);
      
      const processFile = (file: File, index: number) => {
        return new Promise<void>((resolve) => {
          const reader = new FileReader();
          reader.onload = async (e) => {
            const base64 = (e.target?.result as string).split(',')[1];
            const analysis = await analyzePhotoWithGemini(base64, existingFolderNames);
            const primaryFolder = analysis?.primaryFolder || "Unsorted";
            const photoUrl = URL.createObjectURL(file);
            
            const newPhoto: Photo = {
              id: Math.random().toString(36).substr(2, 9),
              url: photoUrl,
              filename: file.name,
              uploadDate: new Date().toISOString().split('T')[0],
              people: [primaryFolder],
              metadata: analysis
            };
            
            setPhotos(prev => [newPhoto, ...prev]);

            setPeople(prevPeople => {
              const updatedPeople = [...prevPeople];
              const existingIndex = updatedPeople.findIndex(p => p.name.toLowerCase() === primaryFolder.toLowerCase());
              
              if (existingIndex > -1) {
                updatedPeople[existingIndex] = {
                  ...updatedPeople[existingIndex],
                  photoCount: updatedPeople[existingIndex].photoCount + 1,
                  thumbnailUrl: updatedPeople[existingIndex].photoCount === 0 ? photoUrl : updatedPeople[existingIndex].thumbnailUrl
                };
              } else {
                updatedPeople.push({
                  id: `folder_${Math.random().toString(36).substr(2, 5)}`,
                  name: primaryFolder,
                  thumbnailUrl: photoUrl,
                  photoCount: 1,
                  email: ''
                });
              }
              return updatedPeople;
            });

            setUploadProgress(Math.round(((index + 1) / totalFiles) * 100));
            setSortingStatus(`Matched: ${primaryFolder}`);
            resolve();
          };
          reader.readAsDataURL(file);
        });
      };

      await processFile(file, i);
    }
    
    setIsUploading(false);
    setCurrentView(AppView.PEOPLE);
  };

  const renderView = () => {
    switch (currentView) {
      case AppView.DASHBOARD:
        return <Dashboard photos={photos} people={people} onNavigate={setCurrentView} onPreview={setPreviewPhoto} />;
      case AppView.GALLERY:
        return <Gallery photos={photos} onShare={setSharingPhoto} onPreview={setPreviewPhoto} />;
      case AppView.PEOPLE:
        return (
          <PeopleView 
            people={people} 
            photos={photos} 
            onSharePerson={(p) => {
              setSharingTarget(p);
              setCurrentView(AppView.MAIL);
            }} 
            onPreviewPhoto={setPreviewPhoto}
          />
        );
      case AppView.MAIL:
        return (
          <MailCenter 
            photos={photos} 
            people={people} 
            preselectedPerson={sharingTarget} 
            onClearPreselect={() => setSharingTarget(null)}
          />
        );
      default:
        return <Dashboard photos={photos} people={people} onNavigate={setCurrentView} onPreview={setPreviewPhoto} />;
    }
  };

  return (
    <div className="flex h-screen overflow-hidden bg-[#0A0C10] font-sans text-slate-200">
      <Sidebar currentView={currentView} setView={setCurrentView} />
      
      <main className="flex-1 flex flex-col overflow-hidden relative">
        <header className="h-24 border-b border-white/5 bg-[#0D1117] flex items-center justify-between px-10 shrink-0 z-10 shadow-2xl">
          <div className="flex items-center gap-8">
            <h1 className="text-xl font-black text-white tracking-tight uppercase flex items-center gap-3">
              <div className="w-2 h-8 bg-indigo-500 rounded-full"></div>
              Drishyamitra
            </h1>
            
            <div className="h-12 w-[1px] bg-white/10"></div>

            <div className="flex items-center gap-3">
              <button 
                onClick={() => setIsCreatingFolder(true)}
                className="bg-white/5 hover:bg-white/10 text-white px-5 py-2.5 rounded-xl border border-white/10 transition-all flex items-center gap-2 text-xs font-bold uppercase tracking-widest"
              >
                <svg className="w-4 h-4 text-indigo-400" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={3} d="M12 4v16m8-8H4" /></svg>
                Create Target Folder
              </button>
            </div>
          </div>
          
          <div className="flex items-center gap-6">
            {isUploading && (
              <div className="flex items-center gap-4 bg-indigo-600/10 px-6 py-3 rounded-2xl border border-indigo-500/20">
                <div className="flex flex-col min-w-[140px]">
                   <span className="text-[9px] font-black text-indigo-400 uppercase tracking-[0.2em]">{sortingStatus}</span>
                   <div className="w-full h-1 bg-white/10 rounded-full mt-2 overflow-hidden">
                      <div className="h-full bg-indigo-500 transition-all duration-300" style={{ width: `${uploadProgress}%` }}></div>
                   </div>
                </div>
              </div>
            )}

            <label className="bg-indigo-600 hover:bg-indigo-500 text-white px-8 py-3.5 rounded-2xl cursor-pointer shadow-2xl transition-all flex items-center gap-3 transform hover:scale-105 active:scale-95">
              <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={3} d="M4 16v1a3 3 0 003 3h10a3 3 0 003-3v-1m-4-4l-4 4m0 0l-4-4m4 4V4" /></svg>
              <span className="font-black uppercase tracking-widest text-[11px]">Upload Bulk & Sort</span>
              <input type="file" multiple accept="image/*" className="hidden" onChange={handleBulkUpload} />
            </label>
          </div>
        </header>

        <div className="flex-1 overflow-y-auto p-12 bg-[#0A0C10] scrollbar-hide">
          {renderView()}
        </div>
      </main>

      {isCreatingFolder && (
        <div className="fixed inset-0 z-[110] flex items-center justify-center p-6 bg-black/90 backdrop-blur-xl animate-in fade-in duration-300">
          <div className="bg-[#161B22] border border-white/10 rounded-[2.5rem] w-full max-w-md p-10 shadow-2xl transform animate-in zoom-in-95 duration-500">
             <h3 className="text-2xl font-black text-white mb-2">New Identity Folder</h3>
             <p className="text-slate-400 text-sm mb-8 font-medium">Upload a reference photo so the AI knows who to look for.</p>
             <div className="space-y-6">
                <input 
                  type="text" 
                  placeholder="e.g. Priya's Wedding" 
                  className="w-full bg-white/5 border border-white/10 rounded-2xl px-6 py-4 outline-none focus:border-indigo-500 text-white font-bold"
                  value={newFolderName}
                  onChange={(e) => setNewFolderName(e.target.value)}
                />
                <label className="flex flex-col items-center justify-center w-full h-40 border-2 border-dashed border-white/10 rounded-[2rem] cursor-pointer hover:bg-white/5 transition-all group">
                   <svg className="w-10 h-10 text-slate-600 group-hover:text-indigo-500 mb-2" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 6v6m0 0v6m0-6h6m-6 0H6" /></svg>
                   <span className="text-xs font-black text-slate-500 uppercase tracking-widest">Select Reference</span>
                   <input type="file" className="hidden" accept="image/*" onChange={handleCreateFolder} />
                </label>
                <button onClick={() => setIsCreatingFolder(false)} className="w-full text-slate-500 font-bold py-2">Cancel</button>
             </div>
          </div>
        </div>
      )}

      {sharingPhoto && <ShareModal photo={sharingPhoto} people={people} onClose={() => setSharingPhoto(null)} />}
      {previewPhoto && (
        <div className="fixed inset-0 z-[60] bg-black/98 backdrop-blur-3xl flex items-center justify-center p-16" onClick={() => setPreviewPhoto(null)}>
          <img src={previewPhoto.url} className="max-w-full max-h-full rounded-[3rem] border border-white/10 shadow-2xl" alt="Preview" />
        </div>
      )}
    </div>
  );
};

export default App;
