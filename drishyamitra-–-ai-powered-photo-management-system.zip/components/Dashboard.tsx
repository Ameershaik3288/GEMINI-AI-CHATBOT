
import React from 'react';
import { Photo, Person, AppView } from '../types';

interface DashboardProps {
  photos: Photo[];
  people: Person[];
  onNavigate: (view: AppView) => void;
  onPreview: (photo: Photo) => void;
}

const Dashboard: React.FC<DashboardProps> = ({ photos, people, onNavigate, onPreview }) => {
  return (
    <div className="space-y-8 animate-in fade-in slide-in-from-bottom-4 duration-500">
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <div className="bg-white p-6 rounded-2xl border border-slate-200 shadow-sm cursor-pointer hover:border-indigo-200 transition" onClick={() => onNavigate(AppView.GALLERY)}>
          <div className="text-slate-500 text-sm font-medium mb-1">Total Photos</div>
          <div className="text-3xl font-bold text-slate-800">{photos.length}</div>
        </div>
        <div className="bg-white p-6 rounded-2xl border border-slate-200 shadow-sm cursor-pointer hover:border-indigo-200 transition" onClick={() => onNavigate(AppView.PEOPLE)}>
          <div className="text-slate-500 text-sm font-medium mb-1">Recognized People</div>
          <div className="text-3xl font-bold text-indigo-600">{people.length}</div>
        </div>
        <div className="bg-white p-6 rounded-2xl border border-slate-200 shadow-sm">
          <div className="text-slate-500 text-sm font-medium mb-1">Last Analysis</div>
          <div className="text-3xl font-bold text-emerald-600">Healthy</div>
        </div>
      </div>

      <section>
        <div className="flex items-center justify-between mb-4">
          <h2 className="text-xl font-bold text-slate-800">Recent People</h2>
          <button onClick={() => onNavigate(AppView.PEOPLE)} className="text-indigo-600 font-bold text-sm hover:underline">View All</button>
        </div>
        <div className="flex gap-4 overflow-x-auto pb-4 scrollbar-hide">
          {people.map(person => (
            <div key={person.id} className="flex flex-col items-center gap-2 shrink-0 group cursor-pointer" onClick={() => onNavigate(AppView.PEOPLE)}>
              <div className="w-20 h-20 rounded-full border-4 border-white shadow-md overflow-hidden group-hover:scale-110 transition-transform duration-300">
                <img src={person.thumbnailUrl} alt={person.name} className="w-full h-full object-cover" />
              </div>
              <span className="text-sm font-bold text-slate-700">{person.name}</span>
            </div>
          ))}
          <div className="w-20 h-20 rounded-full border-2 border-dashed border-slate-300 flex items-center justify-center cursor-pointer hover:bg-white hover:border-indigo-400 transition shrink-0 group" onClick={() => onNavigate(AppView.PEOPLE)}>
            <svg className="w-6 h-6 text-slate-400 group-hover:text-indigo-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 6v6m0 0v6m0-6h6m-6 0H6" />
            </svg>
          </div>
        </div>
      </section>

      <section>
        <div className="flex items-center justify-between mb-4">
          <h2 className="text-xl font-bold text-slate-800">Recent Uploads</h2>
          <button onClick={() => onNavigate(AppView.GALLERY)} className="text-indigo-600 font-bold text-sm hover:underline">View Gallery</button>
        </div>
        <div className="grid grid-cols-2 md:grid-cols-4 lg:grid-cols-5 gap-4">
          {photos.slice(0, 10).map(photo => (
            <div key={photo.id} className="aspect-square rounded-xl overflow-hidden shadow-sm group relative cursor-pointer" onClick={() => onPreview(photo)}>
              <img src={photo.url} alt={photo.filename} className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-700" />
              <div className="absolute inset-0 bg-black/40 opacity-0 group-hover:opacity-100 transition-opacity flex items-end p-3">
                <span className="text-white text-xs font-bold truncate">{photo.filename}</span>
              </div>
            </div>
          ))}
        </div>
      </section>
    </div>
  );
};

export default Dashboard;
