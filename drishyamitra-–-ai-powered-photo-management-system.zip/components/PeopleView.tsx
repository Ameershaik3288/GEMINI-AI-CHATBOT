
import React, { useState } from 'react';
import { Person, Photo } from '../types';

interface PeopleViewProps {
  people: Person[];
  photos: Photo[];
  onSharePerson: (person: Person) => void;
  onPreviewPhoto: (photo: Photo) => void;
}

const PeopleView: React.FC<PeopleViewProps> = ({ people, photos, onSharePerson, onPreviewPhoto }) => {
  const [selectedPerson, setSelectedPerson] = useState<Person | null>(null);

  const getPersonPhotos = (name: string) => {
    return photos.filter(p => p.people.includes(name));
  };

  if (selectedPerson) {
    const personPhotos = getPersonPhotos(selectedPerson.name);
    return (
      <div className="space-y-10 animate-in fade-in slide-in-from-right-8 duration-500">
        <div className="flex items-center gap-8 bg-[#161B22] p-8 rounded-[3rem] border border-white/5 shadow-2xl">
          <button 
            onClick={() => setSelectedPerson(null)}
            className="w-14 h-14 bg-white/5 rounded-3xl flex items-center justify-center text-slate-400 hover:text-white transition-all border border-white/10"
          >
            <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={3} d="M15 19l-7-7 7-7" /></svg>
          </button>
          <div>
            <h2 className="text-4xl font-black text-white tracking-tight">{selectedPerson.name}</h2>
            <p className="text-xs text-indigo-400 font-bold uppercase tracking-[0.3em] mt-2">Isolated Folder • {personPhotos.length} Items</p>
          </div>
          <div className="ml-auto flex gap-4">
            <button className="bg-white/10 text-white px-8 py-4 rounded-2xl font-black uppercase tracking-widest text-[10px] hover:bg-white/20 transition-all flex items-center gap-2">
              <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M8 7v8a2 2 0 002 2h6M8 7V5a2 2 0 012-2h4.586a1 1 0 01.707.293l4.414 4.414a1 1 0 01.293.707V15a2 2 0 01-2 2h-2M8 7H6a2 2 0 00-2 2v10a2 2 0 002 2h8a2 2 0 002-2v-2" /></svg>
              Rename Cluster
            </button>
            <button 
              onClick={() => onSharePerson(selectedPerson)}
              className="bg-indigo-600 text-white px-8 py-4 rounded-2xl font-black uppercase tracking-widest text-[10px] shadow-2xl shadow-indigo-500/20 hover:bg-indigo-500 transition-all"
            >
              Export Folder to Client
            </button>
          </div>
        </div>

        <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 xl:grid-cols-5 gap-8">
          {personPhotos.map(photo => (
            <div key={photo.id} className="group relative aspect-square rounded-[2.5rem] overflow-hidden border-4 border-[#161B22] shadow-2xl bg-slate-800 cursor-pointer transform hover:scale-105 transition-all duration-500" onClick={() => onPreviewPhoto(photo)}>
              <img src={photo.url} className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-1000" alt="Capture" />
              <div className="absolute inset-0 bg-indigo-900/60 opacity-0 group-hover:opacity-100 transition-all flex items-center justify-center backdrop-blur-[2px]">
                 <svg className="w-10 h-10 text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 12a3 3 0 11-6 0 3 3 0 016 0z" /><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M2.458 12C3.732 7.943 7.523 5 12 5c4.478 0 8.268 2.943 9.542 7-1.274 4.057-5.064 7-9.542 7-4.477 0-8.268-2.943-9.542-7z" /></svg>
              </div>
            </div>
          ))}
        </div>
      </div>
    );
  }

  return (
    <div className="space-y-12 animate-in fade-in duration-500">
      <div className="flex items-end justify-between">
        <div>
          <h2 className="text-4xl font-black text-white tracking-tighter">Separated Collections</h2>
          <p className="text-sm text-slate-500 font-bold uppercase tracking-[0.4em] mt-3">Identity clusters from current workspace session</p>
        </div>
        <div className="flex gap-4">
           <button className="bg-[#161B22] border border-white/5 px-8 py-4 rounded-2xl text-[10px] font-black text-slate-400 uppercase tracking-widest hover:text-white transition-all">
             Merge Similar Folders
           </button>
        </div>
      </div>

      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-12">
        {people.map(person => {
          const personPhotos = getPersonPhotos(person.name);
          return (
            <div 
              key={person.id} 
              onClick={() => setSelectedPerson(person)}
              className="group relative cursor-pointer"
            >
              {/* Folder stacking visuals */}
              <div className="absolute inset-0 bg-slate-800 rounded-[3rem] translate-y-4 translate-x-3 rotate-1 group-hover:translate-y-6 group-hover:translate-x-5 transition-all duration-500 opacity-20"></div>
              <div className="absolute inset-0 bg-slate-800 rounded-[3rem] translate-y-2 translate-x-1.5 -rotate-1 group-hover:translate-y-3 group-hover:translate-x-2.5 transition-all duration-500 opacity-40"></div>
              
              <div className="relative bg-[#161B22] rounded-[3rem] border border-white/5 p-8 shadow-2xl group-hover:border-indigo-500/50 transition-all duration-500 flex flex-col min-h-[420px]">
                <div className="relative aspect-square rounded-[2.5rem] overflow-hidden shadow-2xl mb-8 transform group-hover:-translate-y-2 transition-all duration-500 bg-slate-900">
                  <img src={person.thumbnailUrl} alt={person.name} className="w-full h-full object-cover grayscale-[0.5] group-hover:grayscale-0 transition-all duration-500" />
                  <div className="absolute top-4 right-4 bg-indigo-600 text-white px-4 py-2 rounded-2xl font-black text-xs shadow-xl">
                    {personPhotos.length} Photos
                  </div>
                </div>

                <div className="flex-1">
                  <h3 className="text-2xl font-black text-white tracking-tight truncate mb-1">{person.name}</h3>
                  <div className="flex gap-1">
                    {personPhotos.slice(0, 5).map((_, i) => (
                      <div key={i} className="w-2 h-2 rounded-full bg-white/10 group-hover:bg-indigo-500 transition-all" style={{ transitionDelay: `${i * 100}ms` }}></div>
                    ))}
                  </div>
                </div>

                <div className="mt-8 pt-6 border-t border-white/5 flex items-center justify-between">
                  <span className="text-[10px] font-black text-slate-500 uppercase tracking-[0.2em] group-hover:text-indigo-400">Open Folder</span>
                  <div className="w-12 h-12 rounded-2xl bg-white/5 flex items-center justify-center text-slate-400 group-hover:bg-indigo-600 group-hover:text-white transition-all">
                     <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={3} d="M9 5l7 7-7 7" /></svg>
                  </div>
                </div>
              </div>
            </div>
          );
        })}

        <div className="border-2 border-dashed border-white/10 rounded-[3rem] flex flex-col items-center justify-center p-12 hover:bg-white/5 hover:border-indigo-500/50 transition-all group min-h-[420px] cursor-pointer">
          <div className="w-20 h-20 bg-white/5 rounded-3xl flex items-center justify-center mb-6 group-hover:scale-110 transition-all duration-500">
            <svg className="w-8 h-8 text-slate-600 group-hover:text-indigo-500" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={3} d="M12 6v6m0 0v6m0-6h6m-6 0H6" />
            </svg>
          </div>
          <span className="font-black text-lg text-slate-400 group-hover:text-white transition-colors">New Manual Folder</span>
          <span className="text-[10px] text-slate-600 font-bold mt-2 uppercase tracking-widest">Client Setup</span>
        </div>
      </div>
    </div>
  );
};

export default PeopleView;
