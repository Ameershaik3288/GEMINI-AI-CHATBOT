
import React, { useState, useEffect } from 'react';
import { Photo, Person } from '../types';

interface ShareModalProps {
  photo: Photo | null;
  people: Person[];
  onClose: () => void;
}

const ShareModal: React.FC<ShareModalProps> = ({ photo, people, onClose }) => {
  const [method, setMethod] = useState<'email' | 'whatsapp'>('email');
  const [recipient, setRecipient] = useState('');
  const [isSending, setIsSending] = useState(false);
  const [success, setSuccess] = useState(false);

  // Auto-fill logic for the Google Drive-like experience
  useEffect(() => {
    if (photo && photo.people.length > 0) {
      const firstPersonName = photo.people[0];
      const person = people.find(p => p.name.toLowerCase() === firstPersonName.toLowerCase());
      if (person && person.email) {
        setRecipient(person.email);
      }
    }
  }, [photo, people]);

  if (!photo) return null;

  const handleShare = async () => {
    setIsSending(true);
    // Simulate API call to backend delivery service
    await new Promise(resolve => setTimeout(resolve, 1500));
    setIsSending(false);
    setSuccess(true);
    setTimeout(onClose, 1500);
  };

  const handleSelectPerson = (person: Person) => {
    if (method === 'email' && person.email) {
      setRecipient(person.email);
    } else {
      setRecipient(person.name);
    }
  };

  return (
    <div className="fixed inset-0 z-[100] flex items-center justify-center p-4 bg-slate-900/80 backdrop-blur-md animate-in fade-in duration-300">
      <div className="bg-white rounded-[3rem] w-full max-w-md shadow-2xl overflow-hidden border border-slate-100 transform animate-in zoom-in-95 slide-in-from-bottom-8 duration-500">
        <div className="p-8 border-b flex items-center justify-between bg-slate-50/50">
          <div>
            <h3 className="text-2xl font-black text-slate-800 tracking-tight">Delivery Hub</h3>
            <p className="text-xs text-slate-400 font-bold uppercase tracking-widest mt-1">Instant Photo Routing</p>
          </div>
          <button onClick={onClose} className="w-10 h-10 bg-white rounded-2xl flex items-center justify-center text-slate-400 hover:text-slate-600 shadow-sm border transition">
            <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" /></svg>
          </button>
        </div>

        <div className="p-8 space-y-8">
          <div className="flex gap-6 items-center bg-indigo-50/30 p-4 rounded-3xl border border-indigo-100">
            <img src={photo.url} className="w-20 h-20 rounded-2xl object-cover shadow-lg border-2 border-white" alt="Preview" />
            <div className="flex-1 space-y-1 overflow-hidden">
              <p className="font-black text-slate-800 truncate">{photo.filename}</p>
              <div className="flex gap-1 overflow-hidden">
                {photo.people.map(p => (
                   <span key={p} className="text-[9px] bg-indigo-600 text-white px-2 py-0.5 rounded-full font-bold uppercase">{p}</span>
                ))}
              </div>
            </div>
          </div>

          <div className="flex bg-slate-100 p-1.5 rounded-2xl">
            <button 
              onClick={() => setMethod('email')}
              className={`flex-1 py-3 rounded-xl text-sm font-black uppercase tracking-widest transition-all ${method === 'email' ? 'bg-white text-indigo-600 shadow-xl' : 'text-slate-500 hover:text-slate-700'}`}
            >
              Email
            </button>
            <button 
              onClick={() => setMethod('whatsapp')}
              className={`flex-1 py-3 rounded-xl text-sm font-black uppercase tracking-widest transition-all ${method === 'whatsapp' ? 'bg-emerald-500 text-white shadow-xl' : 'text-slate-500 hover:text-slate-700'}`}
            >
              WhatsApp
            </button>
          </div>

          <div className="space-y-6">
            <div>
              <label className="text-xs font-black text-slate-400 uppercase tracking-widest mb-3 block">Recipient Details</label>
              <div className="relative">
                <input 
                  type="text" 
                  placeholder={method === 'email' ? "Enter email address..." : "Enter phone number..."}
                  className="w-full bg-slate-50 border border-slate-200 rounded-2xl px-5 py-4 outline-none focus:ring-4 ring-indigo-500/10 text-slate-800 font-bold transition-all"
                  value={recipient}
                  onChange={(e) => setRecipient(e.target.value)}
                />
                <div className="absolute right-4 top-1/2 -translate-y-1/2 text-indigo-600">
                   <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M16 7a4 4 0 11-8 0 4 4 0 018 0zM12 14a7 7 0 00-7 7h14a7 7 0 00-7-7z" /></svg>
                </div>
              </div>
            </div>

            <div>
              <p className="text-[10px] font-black text-slate-400 uppercase tracking-widest mb-3">Detected Entities</p>
              <div className="flex gap-3 overflow-x-auto pb-2 scrollbar-hide">
                {people.map(person => (
                  <button 
                    key={person.id}
                    onClick={() => handleSelectPerson(person)}
                    className={`flex items-center gap-3 bg-white border px-4 py-2 rounded-2xl shrink-0 transition-all hover:border-indigo-400 ${recipient.includes(person.email || person.name) ? 'border-indigo-600 bg-indigo-50 ring-2 ring-indigo-500/10' : 'border-slate-100 shadow-sm'}`}
                  >
                    <img src={person.thumbnailUrl} className="w-8 h-8 rounded-full object-cover border-2 border-white shadow-sm" alt={person.name} />
                    <div className="text-left">
                      <span className="text-sm font-black text-slate-800 block">{person.name}</span>
                      <span className="text-[10px] text-slate-400 font-bold">{method === 'email' ? person.email : 'WhatsApp'}</span>
                    </div>
                  </button>
                ))}
              </div>
            </div>
          </div>

          {success ? (
            <div className="bg-emerald-50 text-emerald-600 p-6 rounded-3xl flex flex-col items-center gap-2 animate-in zoom-in-95 duration-300 border border-emerald-100">
              <div className="w-12 h-12 bg-emerald-600 text-white rounded-full flex items-center justify-center shadow-lg shadow-emerald-200 mb-2">
                <svg className="w-6 h-6" fill="currentColor" viewBox="0 0 20 20"><path fillRule="evenodd" d="M16.707 5.293a1 1 0 010 1.414l-8 8a1 1 0 01-1.414 0l-4-4a1 1 0 011.414-1.414L8 12.586l7.293-7.293a1 1 0 011.414 0z" clipRule="evenodd" /></svg>
              </div>
              <span className="font-black uppercase tracking-widest text-sm">Transfer Complete</span>
              <p className="text-xs text-emerald-500 font-bold">Photo successfully routed to {recipient}</p>
            </div>
          ) : (
            <button 
              onClick={handleShare}
              disabled={!recipient || isSending}
              className="w-full bg-indigo-600 hover:bg-indigo-700 disabled:bg-slate-100 disabled:text-slate-400 text-white font-black uppercase tracking-widest py-5 rounded-[2rem] transition-all flex items-center justify-center gap-3 shadow-2xl shadow-indigo-500/20 transform active:scale-95"
            >
              {isSending ? (
                <div className="w-6 h-6 border-4 border-white/30 border-t-white rounded-full animate-spin" />
              ) : (
                <>
                  <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 19l9 2-9-18-9 18 9-2zm0 0v-8" /></svg>
                  Authorize Send
                </>
              )}
            </button>
          )}
        </div>
      </div>
    </div>
  );
};

export default ShareModal;
