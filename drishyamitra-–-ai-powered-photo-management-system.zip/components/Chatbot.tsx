
import React, { useState, useRef, useEffect } from 'react';
import { Photo, Person, ChatMessage } from '../types';
import { queryPhotosChat } from '../services/geminiService';

interface ChatbotProps {
  photos: Photo[];
  people: Person[];
  onShareRequested: (photo: Photo) => void;
}

const Chatbot: React.FC<ChatbotProps> = ({ photos, people, onShareRequested }) => {
  const [messages, setMessages] = useState<ChatMessage[]>([]);
  const [input, setInput] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const scrollRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (scrollRef.current) {
      scrollRef.current.scrollTop = scrollRef.current.scrollHeight;
    }
  }, [messages]);

  const handleSend = async () => {
    if (!input.trim() || isLoading) return;

    const userMsg: ChatMessage = {
      id: Date.now().toString(),
      role: 'user',
      content: input,
      timestamp: new Date()
    };

    setMessages(prev => [...prev, userMsg]);
    setInput('');
    setIsLoading(true);

    // Intent detection (simple version)
    const lowerInput = input.toLowerCase();
    if (lowerInput.includes('share') || lowerInput.includes('send')) {
      const targetPerson = people.find(p => lowerInput.includes(p.name.toLowerCase()));
      if (targetPerson) {
        const personPhoto = photos.find(ph => ph.people.includes(targetPerson.name));
        if (personPhoto) {
          const assistantMsg: ChatMessage = {
            id: (Date.now() + 1).toString(),
            role: 'assistant',
            content: `I've found photos of ${targetPerson.name}. Would you like me to share them with ${targetPerson.email || 'their linked account'}?`,
            timestamp: new Date()
          };
          setMessages(prev => [...prev, assistantMsg]);
          onShareRequested(personPhoto);
          setIsLoading(false);
          return;
        }
      }
    }

    // Normal Gemini Chat
    const context = photos.map(p => `Photo ${p.filename} has people: ${p.people.join(', ')} uploaded on ${p.uploadDate}`).join('\n');
    const botResponse = await queryPhotosChat(input, context);
    
    const assistantMsg: ChatMessage = {
      id: (Date.now() + 1).toString(),
      role: 'assistant',
      content: botResponse || "I'm having trouble connecting to my central brain. Try again?",
      timestamp: new Date()
    };

    setMessages(prev => [...prev, assistantMsg]);
    setIsLoading(false);
  };

  return (
    <div className="max-w-4xl mx-auto h-[calc(100vh-12rem)] flex flex-col bg-white rounded-[2.5rem] border shadow-2xl shadow-indigo-500/5 overflow-hidden">
      <div className="bg-indigo-600 p-6 text-white flex items-center justify-between shrink-0">
        <div className="flex items-center gap-4">
          <div className="w-12 h-12 bg-white/20 rounded-2xl flex items-center justify-center backdrop-blur-md">
            <svg className="w-7 h-7" fill="currentColor" viewBox="0 0 24 24">
              <path d="M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm0 18c-4.41 0-8-3.59-8-8s3.59-8 8-8 8 3.59 8 8-3.59 8-8 8zm-5-9h10v2H7z" />
            </svg>
          </div>
          <div>
            <h3 className="font-black text-lg">Drishyamitra AI</h3>
            <p className="text-xs text-indigo-200 font-bold uppercase tracking-widest">Active Intelligence Engine</p>
          </div>
        </div>
        <button className="p-2 hover:bg-white/10 rounded-xl transition">
          <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 7l-.867 12.142A2 2 0 0116.138 21H7.862a2 2 0 01-1.995-1.858L5 7m5 4v6m4-6v6m1-10V4a1 1 0 00-1-1h-4a1 1 0 00-1 1v3M4 7h16" /></svg>
        </button>
      </div>

      <div ref={scrollRef} className="flex-1 overflow-y-auto p-8 space-y-6 scrollbar-hide">
        {messages.length === 0 && (
          <div className="text-center py-16 space-y-8">
            <div className="w-20 h-20 bg-indigo-50 text-indigo-600 rounded-full flex items-center justify-center mx-auto animate-bounce">
              <svg className="w-10 h-10" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M8 12h.01M12 12h.01M16 12h.01M21 12c0 4.418-4.03 8-9 8a9.863 9.863 0 01-4.255-.949L3 20l1.395-3.72C3.512 15.042 3 13.574 3 12c0-4.418 4.03-8 9-8s9 3.582 9 8z" /></svg>
            </div>
            <div>
              <p className="text-slate-400 font-black uppercase tracking-widest text-xs mb-4">Common Operations</p>
              <div className="flex flex-wrap justify-center gap-3">
                {['Share photos with Priya', 'Find Rahul from last month', 'Who is in IMG_001.jpg?', 'Group photos by name'].map(q => (
                  <button 
                    key={q} 
                    onClick={() => { setInput(q); }}
                    className="bg-slate-50 border border-slate-100 hover:border-indigo-200 hover:bg-indigo-50 hover:text-indigo-600 px-5 py-2.5 rounded-2xl text-sm font-bold text-slate-600 transition-all transform hover:scale-105"
                  >
                    {q}
                  </button>
                ))}
              </div>
            </div>
          </div>
        )}
        
        {messages.map((m) => (
          <div key={m.id} className={`flex ${m.role === 'user' ? 'justify-end' : 'justify-start'} animate-in slide-in-from-bottom-2 duration-300`}>
            <div className={`max-w-[85%] p-5 rounded-3xl ${
              m.role === 'user' 
              ? 'bg-indigo-600 text-white rounded-tr-none shadow-xl shadow-indigo-200' 
              : 'bg-slate-50 text-slate-800 rounded-tl-none border border-slate-100'
            }`}>
              <p className="text-[0.9375rem] leading-relaxed whitespace-pre-wrap font-medium">{m.content}</p>
              <p className={`text-[10px] mt-2 font-black uppercase tracking-widest ${m.role === 'user' ? 'text-indigo-200' : 'text-slate-400'}`}>
                {m.timestamp.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
              </p>
            </div>
          </div>
        ))}
        {isLoading && (
          <div className="flex justify-start">
            <div className="bg-slate-50 p-5 rounded-3xl rounded-tl-none border border-slate-100 flex gap-2">
              <div className="w-2 h-2 bg-indigo-400 rounded-full animate-bounce"></div>
              <div className="w-2 h-2 bg-indigo-400 rounded-full animate-bounce delay-75"></div>
              <div className="w-2 h-2 bg-indigo-400 rounded-full animate-bounce delay-150"></div>
            </div>
          </div>
        )}
      </div>

      <div className="p-6 border-t bg-slate-50 shrink-0">
        <div className="flex items-center gap-3 bg-white rounded-2xl p-2 shadow-sm border border-slate-200 focus-within:ring-4 ring-indigo-500/10 transition-all">
          <button className="p-3 text-slate-400 hover:text-indigo-600 hover:bg-indigo-50 rounded-xl transition">
            <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 19l9 2-9-18-9 18 9-2zm0 0v-8" /></svg>
          </button>
          <input 
            type="text" 
            placeholder="Search, share, or manage your library..." 
            className="flex-1 bg-transparent outline-none text-sm px-2 font-bold text-slate-700"
            value={input}
            onChange={(e) => setInput(e.target.value)}
            onKeyDown={(e) => e.key === 'Enter' && handleSend()}
          />
          <button 
            onClick={handleSend}
            disabled={!input.trim() || isLoading}
            className="bg-indigo-600 hover:bg-indigo-700 disabled:bg-slate-200 text-white p-3 rounded-xl transition-all shadow-lg shadow-indigo-100 transform active:scale-95"
          >
            <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M13 5l7 7-7 7M5 5l7 7-7 7" /></svg>
          </button>
        </div>
      </div>
    </div>
  );
};

export default Chatbot;
