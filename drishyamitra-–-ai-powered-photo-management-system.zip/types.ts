
export interface Photo {
  id: string;
  url: string;
  filename: string;
  uploadDate: string;
  people: string[];
  metadata?: any;
}

export interface Person {
  id: string;
  name: string;
  email?: string;
  thumbnailUrl: string;
  photoCount: number;
}

export interface ChatMessage {
  id: string;
  role: 'user' | 'assistant';
  content: string;
  timestamp: Date;
  attachments?: string[];
}

export interface DeliveryHistory {
  id: string;
  photoId: string;
  recipient: string;
  channel: 'email' | 'whatsapp';
  sentAt: string;
  status: 'sent' | 'failed' | 'pending';
}

export enum AppView {
  DASHBOARD = 'DASHBOARD',
  GALLERY = 'GALLERY',
  PEOPLE = 'PEOPLE',
  MAIL = 'MAIL',
  SETTINGS = 'SETTINGS'
}
