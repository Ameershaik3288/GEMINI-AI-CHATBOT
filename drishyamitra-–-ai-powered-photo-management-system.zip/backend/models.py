
from app import db
from datetime import datetime

class User(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    email = db.Column(db.String(120), unique=True, nullable=False)
    password_hash = db.Column(db.String(128))
    photos = db.relationship('Photo', backref='owner', lazy=True)

class Photo(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    filename = db.Column(db.String(255), nullable=False)
    file_path = db.Column(db.String(512), nullable=False)
    upload_date = db.Column(db.DateTime, default=datetime.utcnow)
    user_id = db.Column(db.Integer, db.ForeignKey('user.id'))
    faces = db.relationship('Face', backref='photo', lazy=True)
    deliveries = db.relationship('DeliveryHistory', backref='photo', lazy=True)

class Person(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(100), nullable=True)
    email = db.Column(db.String(120), nullable=True)
    embedding = db.Column(db.PickleType) # Use pgvector in production
    thumbnail_path = db.Column(db.String(512))
    faces = db.relationship('Face', backref='person', lazy=True)

class Face(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    photo_id = db.Column(db.Integer, db.ForeignKey('photo.id'))
    person_id = db.Column(db.Integer, db.ForeignKey('person.id'))
    box_coordinates = db.Column(db.JSON) # [x, y, w, h]

class DeliveryHistory(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    photo_id = db.Column(db.Integer, db.ForeignKey('photo.id'))
    recipient = db.Column(db.String(255), nullable=False)
    channel = db.Column(db.String(20)) # 'email', 'whatsapp'
    sent_at = db.Column(db.DateTime, default=datetime.utcnow)
    status = db.Column(db.String(20), default='pending') # 'sent', 'failed'
