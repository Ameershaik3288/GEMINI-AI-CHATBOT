
import os
from flask import Flask
from flask_cors import CORS
from flask_sqlalchemy import SQLAlchemy
from flask_jwt_extended import JWTManager
from celery import Celery
from dotenv import load_dotenv

load_dotenv()

# Initialize DB and JWT
db = SQLAlchemy()
jwt = JWTManager()

def make_celery(app):
    celery = Celery(
        app.import_name,
        backend=app.config['CELERY_RESULT_BACKEND'],
        broker=app.config['CELERY_BROKER_URL']
    )
    celery.conf.update(app.config)
    return celery

def create_app():
    app = Flask(__name__)
    
    # Configuration
    app.config['SQLALCHEMY_DATABASE_URI'] = os.getenv('DATABASE_URL', 'sqlite:///drishyamitra.db')
    app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False
    app.config['JWT_SECRET_KEY'] = os.getenv('JWT_SECRET', 'drishyamitra-secure-key-123')
    app.config['CELERY_BROKER_URL'] = os.getenv('REDIS_URL', 'redis://localhost:6379/0')
    app.config['CELERY_RESULT_BACKEND'] = os.getenv('REDIS_URL', 'redis://localhost:6379/0')
    
    # Extensions
    CORS(app)
    db.init_app(app)
    jwt.init_app(app)
    
    # Register Blueprints
    from blueprints.auth import auth_bp
    from blueprints.photos import photos_bp
    from blueprints.chat import chat_bp
    from blueprints.delivery import delivery_bp
    
    app.register_blueprint(auth_bp, url_prefix='/api/auth')
    app.register_blueprint(photos_bp, url_prefix='/api/photos')
    app.register_blueprint(chat_bp, url_prefix='/api/chat')
    app.register_blueprint(delivery_bp, url_prefix='/api/delivery')
    
    with app.app_context():
        db.create_all()
        
    return app

app = create_app()
celery_app = make_celery(app)

if __name__ == '__main__':
    app.run(debug=True, port=5000)
