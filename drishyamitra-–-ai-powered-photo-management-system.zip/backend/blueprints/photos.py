
import os
import uuid
from flask import Blueprint, request, jsonify
from flask_jwt_extended import jwt_required, get_jwt_identity
from werkzeug.utils import secure_filename
from models import Photo, db
from tasks import analyze_photo_task

photos_bp = Blueprint('photos', __name__)

UPLOAD_FOLDER = 'storage/photos'
os.makedirs(UPLOAD_FOLDER, exist_ok=True)

@photos_bp.route('/upload', methods=['POST'])
@jwt_required()
def upload_photo():
    if 'photo' not in request.files:
        return jsonify({"msg": "No file part"}), 400
        
    file = request.files['photo']
    if file.filename == '':
        return jsonify({"msg": "No selected file"}), 400
        
    user_id = get_jwt_identity()
    ext = os.path.splitext(file.filename)[1]
    filename = f"{uuid.uuid4()}{ext}"
    file_path = os.path.join(UPLOAD_FOLDER, filename)
    file.save(file_path)
    
    new_photo = Photo(
        filename=file.filename,
        file_path=file_path,
        user_id=user_id
    )
    db.session.add(new_photo)
    db.session.commit()
    
    # Trigger AI processing
    analyze_photo_task.delay(new_photo.id)
    
    return jsonify({
        "msg": "Photo uploaded and queued for processing",
        "photo_id": new_photo.id
    }), 202

@photos_bp.route('/', methods=['GET'])
@jwt_required()
def get_photos():
    user_id = get_jwt_identity()
    photos = Photo.query.filter_by(user_id=user_id).all()
    return jsonify([{
        "id": p.id,
        "filename": p.filename,
        "upload_date": p.upload_date.isoformat()
    } for p in photos]), 200
