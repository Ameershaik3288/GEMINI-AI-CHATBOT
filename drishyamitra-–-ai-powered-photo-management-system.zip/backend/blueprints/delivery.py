
import os
import smtplib
from email.mime.text import MIMEText
from email.mime.multipart import MIMEMultipart
from flask import Blueprint, request, jsonify
from flask_jwt_extended import jwt_required, get_jwt_identity
from models import Photo, DeliveryHistory, db

delivery_bp = Blueprint('delivery', __name__)

def send_real_email(recipient_email, subject, body):
    """
    Utility to send a real email using SMTP.
    Requires environment variables: SMTP_SERVER, SMTP_PORT, SMTP_USER, SMTP_PASS
    """
    smtp_server = os.getenv('SMTP_SERVER', 'smtp.gmail.com')
    smtp_port = int(os.getenv('SMTP_PORT', 587))
    smtp_user = os.getenv('SMTP_USER')
    smtp_pass = os.getenv('SMTP_PASS')

    if not smtp_user or not smtp_pass:
        print("SMTP Credentials not configured. Email will be logged but not sent.")
        return False

    try:
        msg = MIMEMultipart()
        msg['From'] = smtp_user
        msg['To'] = recipient_email
        msg['Subject'] = subject
        msg.attach(MIMEText(body, 'plain'))

        server = smtplib.SMTP(smtp_server, smtp_port)
        server.starttls()
        server.login(smtp_user, smtp_pass)
        server.send_message(msg)
        server.quit()
        return True
    except Exception as e:
        print(f"SMTP Error: {str(e)}")
        return False

@delivery_bp.route('/send', methods=['POST'])
@jwt_required()
def send_photo():
    data = request.json
    photo_ids = data.get('photoIds', [])
    recipient = data.get('recipient')
    subject = data.get('subject', 'Photos from Drishyamitra')
    message = data.get('message', '')
    channel = data.get('channel', 'email')
    
    if not recipient:
        return jsonify({"msg": "Recipient is required"}), 400

    # Build the email body with links to photos
    photos_context = ""
    for pid in photo_ids:
        photo = Photo.query.get(pid)
        if photo:
            photos_context += f"- {photo.filename}: [Link to Storage/CDN]\n"

    full_body = f"{message}\n\nYour Photo Package:\n{photos_context}\n\nDelivered via Drishyamitra AI."

    # Attempt to send
    success = send_real_email(recipient, subject, full_body)
    
    # Log to history regardless of outcome
    for pid in photo_ids:
        new_delivery = DeliveryHistory(
            photo_id=pid,
            recipient=recipient,
            channel=channel,
            status='sent' if success else 'failed'
        )
        db.session.add(new_delivery)
    
    db.session.commit()
    
    if success:
        return jsonify({"msg": f"Photos successfully delivered to {recipient}"}), 200
    else:
        return jsonify({
            "msg": "Failed to send email. Check SMTP configuration in backend .env",
            "error": "SMTP_CREDENTIALS_MISSING"
        }), 500

@delivery_bp.route('/history', methods=['GET'])
@jwt_required()
def get_history():
    history = DeliveryHistory.query.order_by(DeliveryHistory.sent_at.desc()).all()
    return jsonify([{
        "id": h.id,
        "photo": h.photo.filename if h.photo else "Unknown",
        "recipient": h.recipient,
        "channel": h.channel,
        "sent_at": h.sent_at.isoformat(),
        "status": h.status
    } for h in history]), 200
