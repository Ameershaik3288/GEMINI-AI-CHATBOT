
from flask import Blueprint, request, jsonify
from flask_jwt_extended import jwt_required, get_jwt_identity
from models import Photo, Person, Face
from google import generativeai as genai
import os

chat_bp = Blueprint('chat', __name__)

# Configure Gemini for backend usage if needed
# Note: System instructions for Gemini 3
@chat_bp.route('/query', methods=['POST'])
@jwt_required()
def query_assistant():
    data = request.json
    query = data.get('query')
    user_id = get_jwt_identity()
    
    # Fetch user context
    photos = Photo.query.filter_by(user_id=user_id).all()
    context = []
    for p in photos:
        people_names = [f.person.name or "Unknown" for f in p.faces if f.person]
        context.append(f"Photo {p.filename} contains: {', '.join(people_names)}")
        
    context_str = "\n".join(context)
    
    # Gemini Logic
    # In this simplified version, we handle the generation logic
    # In a full production app, this would use the @google/genai SDK correctly
    # but since this is a backend script, we might use a library or hit the API directly.
    # For this project, we'll assume the frontend handles the heavy Gemini lifting
    # but the backend provides the metadata context.
    
    return jsonify({
        "context": context_str,
        "msg": "Metadata context retrieved. Proceed with AI analysis."
    }), 200
