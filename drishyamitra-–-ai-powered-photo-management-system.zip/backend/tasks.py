
from app import celery_app, db
from models import Photo, Face, Person
from deepface import DeepFace
import cv2
import os
import numpy as np

@celery_app.task
def analyze_photo_task(photo_id):
    photo = Photo.query.get(photo_id)
    if not photo:
        return
        
    try:
        # Detect faces and extract embeddings
        results = DeepFace.represent(
            img_path=photo.file_path,
            model_name='Facenet512',
            detector_backend='retinaface',
            enforce_detection=False
        )
        
        for face_data in results:
            embedding = face_data['embedding']
            area = face_data['facial_area'] # x, y, w, h
            
            # Simple Euclidean distance matching for demo
            # In production, use pgvector or Pinecone
            best_match = None
            threshold = 10.0 # Adjust based on model
            
            existing_people = Person.query.all()
            for p in existing_people:
                if p.embedding:
                    dist = np.linalg.norm(np.array(embedding) - np.array(p.embedding))
                    if dist < threshold:
                        best_match = p
                        break
            
            if not best_match:
                # Create new person
                best_match = Person(embedding=embedding)
                db.session.add(best_match)
                db.session.flush() # Get ID
            
            new_face = Face(
                photo_id=photo.id,
                person_id=best_match.id,
                box_coordinates=area
            )
            db.session.add(new_face)
            
        db.session.commit()
    except Exception as e:
        print(f"Error analyzing photo {photo_id}: {str(e)}")
        db.session.rollback()
