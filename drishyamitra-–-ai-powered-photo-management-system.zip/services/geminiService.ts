
import { GoogleGenAI, Type } from "@google/genai";

// Analyze a photo and match it against existing identities or hints
export const analyzePhotoWithGemini = async (base64Image: string, existingFolders: string[], folderHint?: string) => {
  const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
  
  try {
    const contextText = existingFolders.length > 0 
      ? `Existing known folders/people: [${existingFolders.join(", ")}].`
      : "No existing folders yet.";

    const hintText = folderHint 
      ? `The user is specifically looking for "${folderHint}".` 
      : "Identify the subject and suggest a folder.";

    const response = await ai.models.generateContent({
      model: 'gemini-3-flash-preview',
      contents: {
        parts: [
          { text: `Act as a High-Speed Photo Sorting Agent. 
            CONTEXT: ${contextText}
            USER HINT: ${hintText}
            
            TASK: 
            1. Look at the image provided.
            2. If the person in the image matches one of the 'Existing known folders', you MUST set 'primaryFolder' to that exact name.
            3. If the person matches the 'USER HINT', set 'primaryFolder' to the hint name.
            4. If it is a completely new person, create a new logical name like 'Person: [Descriptor]'.
            5. Return the result in JSON.` },
          { inlineData: { mimeType: "image/jpeg", data: base64Image } }
        ]
      },
      config: {
        responseMimeType: "application/json",
        responseSchema: {
          type: Type.OBJECT,
          properties: {
            detectedPeople: {
              type: Type.ARRAY,
              items: { type: Type.STRING },
              description: "All identities found in the image"
            },
            primaryFolder: {
              type: Type.STRING,
              description: "The folder name where this photo strictly belongs"
            },
            isMatch: {
              type: Type.BOOLEAN,
              description: "True if it matches an existing folder or hint"
            }
          },
          required: ["detectedPeople", "primaryFolder", "isMatch"]
        }
      }
    });

    return JSON.parse(response.text || "{}");
  } catch (error) {
    console.error("Sorting Error:", error);
    return null;
  }
};

export const queryPhotosChat = async (prompt: string, context: string) => {
  const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
  try {
    const response = await ai.models.generateContent({
      model: 'gemini-3-flash-preview',
      contents: prompt,
      config: {
        systemInstruction: `You are Drishyamitra AI. Library Context: ${context}`,
      }
    });
    return response.text;
  } catch (error) {
    return "Error connecting to AI brain.";
  }
};
